
__version__ = "0.1.1"
from nmesh.core import *
from nmesh.functional import *

cfg = load_config()
