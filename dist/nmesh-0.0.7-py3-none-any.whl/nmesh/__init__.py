
__version__ = "0.0.7"
from nmesh.core import *
from nmesh.functional import *

cfg = load_config()
