__version__ = "0.1.4"

from nmesh.core import *
from nmesh.functional import *

cfg = load_config()
