
__version__ = "0.0.5"
from nmesh.core import *
from nmesh.functional import *

cfg = load_config()
