__version__ = "0.1.3a0"

from nmesh.core import *
from nmesh.functional import *

cfg = load_config()
